﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReadingTree
{
    public partial class LevelsMenu : Form
    {
        private string group_name = "";
        public LevelsMenu()
        {
            InitializeComponent();
        }
        public LevelsMenu(string group_name)
        {
            InitializeComponent();
            this.group_name = group_name;
        }
        public void SetGroupName(string group)
        {
            this.group_name = group;
        }
        private void LevelsMenu_Load(object sender, EventArgs e)
        {
            headerName.Text = group_name;
            List<List<string>> words = Methods.GetAllWords(group_name);
            level1Box.DataSource = words[0];
            level2Box.DataSource = words[1];
            level3Box.DataSource = words[2];
            level4Box.DataSource = words[3];
            level5Box.DataSource = words[4];
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            MainMenu main = new MainMenu();
            main.Show();
            Close();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            if (level1Box.SelectedIndex == -1) ;

            else wordsList.Items.Add(level1Box.SelectedItem);
            if (level2Box.SelectedIndex == -1) ;

            else wordsList.Items.Add(level2Box.SelectedItem);
            if (level3Box.SelectedIndex == -1) ;

            else wordsList.Items.Add(level3Box.SelectedItem);
            if (level4Box.SelectedIndex == -1) ;

            else wordsList.Items.Add(level4Box.SelectedItem);
            if (level5Box.SelectedIndex == -1) ;

            else wordsList.Items.Add(level5Box.SelectedItem);

        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            wordsList.Items.Remove(wordsList.SelectedItem);
            
        }
    }
}
