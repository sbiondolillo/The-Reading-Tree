﻿namespace ReadingTree
{
    partial class BlendsInitialMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBlendsInitialT = new System.Windows.Forms.Button();
            this.btnBlendsInitialS = new System.Windows.Forms.Button();
            this.btnBlendsInitialP = new System.Windows.Forms.Button();
            this.btnBlendsInitialMixed = new System.Windows.Forms.Button();
            this.btnBlendsInitialG = new System.Windows.Forms.Button();
            this.btnBlendsInitialF = new System.Windows.Forms.Button();
            this.btnBlendsInitialD = new System.Windows.Forms.Button();
            this.btnBlendsInitialC = new System.Windows.Forms.Button();
            this.btnBlendsInitialB = new System.Windows.Forms.Button();
            this.BlendsInitialPromptLabel = new System.Windows.Forms.Label();
            this.BlendsInitiallabel = new System.Windows.Forms.Label();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBlendsInitialT
            // 
            this.btnBlendsInitialT.Location = new System.Drawing.Point(456, 323);
            this.btnBlendsInitialT.Name = "btnBlendsInitialT";
            this.btnBlendsInitialT.Size = new System.Drawing.Size(125, 70);
            this.btnBlendsInitialT.TabIndex = 21;
            this.btnBlendsInitialT.Text = "T";
            this.btnBlendsInitialT.UseVisualStyleBackColor = true;
            this.btnBlendsInitialT.Click += new System.EventHandler(this.btnBlendsInitialT_Click);
            // 
            // btnBlendsInitialS
            // 
            this.btnBlendsInitialS.Location = new System.Drawing.Point(327, 323);
            this.btnBlendsInitialS.Name = "btnBlendsInitialS";
            this.btnBlendsInitialS.Size = new System.Drawing.Size(125, 70);
            this.btnBlendsInitialS.TabIndex = 20;
            this.btnBlendsInitialS.Text = "S";
            this.btnBlendsInitialS.UseVisualStyleBackColor = true;
            this.btnBlendsInitialS.Click += new System.EventHandler(this.btnBlendsInitialS_Click);
            // 
            // btnBlendsInitialP
            // 
            this.btnBlendsInitialP.Location = new System.Drawing.Point(198, 323);
            this.btnBlendsInitialP.Name = "btnBlendsInitialP";
            this.btnBlendsInitialP.Size = new System.Drawing.Size(125, 70);
            this.btnBlendsInitialP.TabIndex = 19;
            this.btnBlendsInitialP.Text = "P";
            this.btnBlendsInitialP.UseVisualStyleBackColor = true;
            this.btnBlendsInitialP.Click += new System.EventHandler(this.btnBlendsInitialP_Click);
            // 
            // btnBlendsInitialMixed
            // 
            this.btnBlendsInitialMixed.Location = new System.Drawing.Point(456, 234);
            this.btnBlendsInitialMixed.Name = "btnBlendsInitialMixed";
            this.btnBlendsInitialMixed.Size = new System.Drawing.Size(125, 70);
            this.btnBlendsInitialMixed.TabIndex = 18;
            this.btnBlendsInitialMixed.Text = "Mixed";
            this.btnBlendsInitialMixed.UseVisualStyleBackColor = true;
            this.btnBlendsInitialMixed.Click += new System.EventHandler(this.btnBlendsInitialMixed_Click);
            // 
            // btnBlendsInitialG
            // 
            this.btnBlendsInitialG.Location = new System.Drawing.Point(327, 234);
            this.btnBlendsInitialG.Name = "btnBlendsInitialG";
            this.btnBlendsInitialG.Size = new System.Drawing.Size(125, 70);
            this.btnBlendsInitialG.TabIndex = 17;
            this.btnBlendsInitialG.Text = "G";
            this.btnBlendsInitialG.UseVisualStyleBackColor = true;
            this.btnBlendsInitialG.Click += new System.EventHandler(this.btnBlendsInitialG_Click);
            // 
            // btnBlendsInitialF
            // 
            this.btnBlendsInitialF.Location = new System.Drawing.Point(198, 234);
            this.btnBlendsInitialF.Name = "btnBlendsInitialF";
            this.btnBlendsInitialF.Size = new System.Drawing.Size(125, 70);
            this.btnBlendsInitialF.TabIndex = 16;
            this.btnBlendsInitialF.Text = "F";
            this.btnBlendsInitialF.UseVisualStyleBackColor = true;
            this.btnBlendsInitialF.Click += new System.EventHandler(this.btnBlendsInitialF_Click);
            // 
            // btnBlendsInitialD
            // 
            this.btnBlendsInitialD.Location = new System.Drawing.Point(456, 151);
            this.btnBlendsInitialD.Name = "btnBlendsInitialD";
            this.btnBlendsInitialD.Size = new System.Drawing.Size(125, 70);
            this.btnBlendsInitialD.TabIndex = 15;
            this.btnBlendsInitialD.Text = "D";
            this.btnBlendsInitialD.UseVisualStyleBackColor = true;
            this.btnBlendsInitialD.Click += new System.EventHandler(this.btnBlendsInitialD_Click);
            // 
            // btnBlendsInitialC
            // 
            this.btnBlendsInitialC.Location = new System.Drawing.Point(327, 151);
            this.btnBlendsInitialC.Name = "btnBlendsInitialC";
            this.btnBlendsInitialC.Size = new System.Drawing.Size(125, 70);
            this.btnBlendsInitialC.TabIndex = 14;
            this.btnBlendsInitialC.Text = "C";
            this.btnBlendsInitialC.UseVisualStyleBackColor = true;
            this.btnBlendsInitialC.Click += new System.EventHandler(this.btnBlendsInitialC_Click);
            // 
            // btnBlendsInitialB
            // 
            this.btnBlendsInitialB.Location = new System.Drawing.Point(198, 151);
            this.btnBlendsInitialB.Name = "btnBlendsInitialB";
            this.btnBlendsInitialB.Size = new System.Drawing.Size(125, 70);
            this.btnBlendsInitialB.TabIndex = 13;
            this.btnBlendsInitialB.Text = "B";
            this.btnBlendsInitialB.UseVisualStyleBackColor = true;
            this.btnBlendsInitialB.Click += new System.EventHandler(this.btnBlendsInitialB_Click);
            // 
            // BlendsInitialPromptLabel
            // 
            this.BlendsInitialPromptLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BlendsInitialPromptLabel.AutoSize = true;
            this.BlendsInitialPromptLabel.Location = new System.Drawing.Point(233, 88);
            this.BlendsInitialPromptLabel.Name = "BlendsInitialPromptLabel";
            this.BlendsInitialPromptLabel.Size = new System.Drawing.Size(313, 20);
            this.BlendsInitialPromptLabel.TabIndex = 23;
            this.BlendsInitialPromptLabel.Text = "Please select a category below to continue!";
            // 
            // BlendsInitiallabel
            // 
            this.BlendsInitiallabel.AutoSize = true;
            this.BlendsInitiallabel.Location = new System.Drawing.Point(338, 41);
            this.BlendsInitiallabel.Name = "BlendsInitiallabel";
            this.BlendsInitiallabel.Size = new System.Drawing.Size(103, 20);
            this.BlendsInitiallabel.TabIndex = 22;
            this.BlendsInitiallabel.Text = "Blends, Initial";
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.Location = new System.Drawing.Point(327, 419);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(125, 70);
            this.btnMainMenu.TabIndex = 25;
            this.btnMainMenu.Text = "Main Menu";
            this.btnMainMenu.UseVisualStyleBackColor = true;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            // 
            // BlendsInitialMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(778, 544);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.BlendsInitialPromptLabel);
            this.Controls.Add(this.BlendsInitiallabel);
            this.Controls.Add(this.btnBlendsInitialT);
            this.Controls.Add(this.btnBlendsInitialS);
            this.Controls.Add(this.btnBlendsInitialP);
            this.Controls.Add(this.btnBlendsInitialMixed);
            this.Controls.Add(this.btnBlendsInitialG);
            this.Controls.Add(this.btnBlendsInitialF);
            this.Controls.Add(this.btnBlendsInitialD);
            this.Controls.Add(this.btnBlendsInitialC);
            this.Controls.Add(this.btnBlendsInitialB);
            this.Name = "BlendsInitialMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "The Reading Tree";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBlendsInitialT;
        private System.Windows.Forms.Button btnBlendsInitialS;
        private System.Windows.Forms.Button btnBlendsInitialP;
        private System.Windows.Forms.Button btnBlendsInitialMixed;
        private System.Windows.Forms.Button btnBlendsInitialG;
        private System.Windows.Forms.Button btnBlendsInitialF;
        private System.Windows.Forms.Button btnBlendsInitialD;
        private System.Windows.Forms.Button btnBlendsInitialC;
        private System.Windows.Forms.Button btnBlendsInitialB;
        private System.Windows.Forms.Label BlendsInitialPromptLabel;
        private System.Windows.Forms.Label BlendsInitiallabel;
        private System.Windows.Forms.Button btnMainMenu;
    }
}