﻿namespace ReadingTree
{
    partial class BlendsLetterBlendsMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSchwaAAlaska = new System.Windows.Forms.Button();
            this.btnQUASquash = new System.Windows.Forms.Button();
            this.btnOY = new System.Windows.Forms.Button();
            this.btnWAWater = new System.Windows.Forms.Button();
            this.btnDGE = new System.Windows.Forms.Button();
            this.btnAbleLatinSuffix = new System.Windows.Forms.Button();
            this.btnOWPlow = new System.Windows.Forms.Button();
            this.btnOUOut = new System.Windows.Forms.Button();
            this.btnAll = new System.Windows.Forms.Button();
            this.btnALALLMixed = new System.Windows.Forms.Button();
            this.btnSEasZ = new System.Windows.Forms.Button();
            this.btnQU = new System.Windows.Forms.Button();
            this.BlendsLetterBlendsPromptlabel = new System.Windows.Forms.Label();
            this.BlendsLetterBlendslabel = new System.Windows.Forms.Label();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSchwaAAlaska
            // 
            this.btnSchwaAAlaska.Location = new System.Drawing.Point(347, 198);
            this.btnSchwaAAlaska.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSchwaAAlaska.Name = "btnSchwaAAlaska";
            this.btnSchwaAAlaska.Size = new System.Drawing.Size(83, 45);
            this.btnSchwaAAlaska.TabIndex = 27;
            this.btnSchwaAAlaska.Text = "schwa a (Alaska)";
            this.btnSchwaAAlaska.UseVisualStyleBackColor = true;
            this.btnSchwaAAlaska.Click += new System.EventHandler(this.btnSchwaAAlaska_Click);
            // 
            // btnQUASquash
            // 
            this.btnQUASquash.Location = new System.Drawing.Point(261, 198);
            this.btnQUASquash.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnQUASquash.Name = "btnQUASquash";
            this.btnQUASquash.Size = new System.Drawing.Size(83, 45);
            this.btnQUASquash.TabIndex = 26;
            this.btnQUASquash.Text = "qua (squash)";
            this.btnQUASquash.UseVisualStyleBackColor = true;
            this.btnQUASquash.Click += new System.EventHandler(this.btnQUASquash_Click);
            // 
            // btnOY
            // 
            this.btnOY.Location = new System.Drawing.Point(175, 198);
            this.btnOY.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnOY.Name = "btnOY";
            this.btnOY.Size = new System.Drawing.Size(83, 45);
            this.btnOY.TabIndex = 25;
            this.btnOY.Text = "oy";
            this.btnOY.UseVisualStyleBackColor = true;
            this.btnOY.Click += new System.EventHandler(this.btnOY_Click);
            // 
            // btnWAWater
            // 
            this.btnWAWater.Location = new System.Drawing.Point(89, 198);
            this.btnWAWater.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnWAWater.Name = "btnWAWater";
            this.btnWAWater.Size = new System.Drawing.Size(83, 45);
            this.btnWAWater.TabIndex = 24;
            this.btnWAWater.Text = "wa (water)";
            this.btnWAWater.UseVisualStyleBackColor = true;
            this.btnWAWater.Click += new System.EventHandler(this.btnWAWater_Click);
            // 
            // btnDGE
            // 
            this.btnDGE.Location = new System.Drawing.Point(347, 140);
            this.btnDGE.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnDGE.Name = "btnDGE";
            this.btnDGE.Size = new System.Drawing.Size(83, 45);
            this.btnDGE.TabIndex = 23;
            this.btnDGE.Text = "dge";
            this.btnDGE.UseVisualStyleBackColor = true;
            this.btnDGE.Click += new System.EventHandler(this.btnDGE_Click);
            // 
            // btnAbleLatinSuffix
            // 
            this.btnAbleLatinSuffix.Location = new System.Drawing.Point(261, 140);
            this.btnAbleLatinSuffix.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAbleLatinSuffix.Name = "btnAbleLatinSuffix";
            this.btnAbleLatinSuffix.Size = new System.Drawing.Size(83, 45);
            this.btnAbleLatinSuffix.TabIndex = 22;
            this.btnAbleLatinSuffix.Text = "Able (Latin Suffix)";
            this.btnAbleLatinSuffix.UseVisualStyleBackColor = true;
            this.btnAbleLatinSuffix.Click += new System.EventHandler(this.btnAbleLatinSuffix_Click);
            // 
            // btnOWPlow
            // 
            this.btnOWPlow.Location = new System.Drawing.Point(175, 140);
            this.btnOWPlow.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnOWPlow.Name = "btnOWPlow";
            this.btnOWPlow.Size = new System.Drawing.Size(83, 45);
            this.btnOWPlow.TabIndex = 21;
            this.btnOWPlow.Text = "ow (plow)";
            this.btnOWPlow.UseVisualStyleBackColor = true;
            this.btnOWPlow.Click += new System.EventHandler(this.btnOWPlow_Click);
            // 
            // btnOUOut
            // 
            this.btnOUOut.Location = new System.Drawing.Point(89, 140);
            this.btnOUOut.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnOUOut.Name = "btnOUOut";
            this.btnOUOut.Size = new System.Drawing.Size(83, 45);
            this.btnOUOut.TabIndex = 20;
            this.btnOUOut.Text = "ou (out)";
            this.btnOUOut.UseVisualStyleBackColor = true;
            this.btnOUOut.Click += new System.EventHandler(this.btnOUOut_Click);
            // 
            // btnAll
            // 
            this.btnAll.Location = new System.Drawing.Point(347, 86);
            this.btnAll.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(83, 45);
            this.btnAll.TabIndex = 19;
            this.btnAll.Text = "all";
            this.btnAll.UseVisualStyleBackColor = true;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // btnALALLMixed
            // 
            this.btnALALLMixed.Location = new System.Drawing.Point(261, 86);
            this.btnALALLMixed.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnALALLMixed.Name = "btnALALLMixed";
            this.btnALALLMixed.Size = new System.Drawing.Size(83, 45);
            this.btnALALLMixed.TabIndex = 18;
            this.btnALALLMixed.Text = "al/all mixed";
            this.btnALALLMixed.UseVisualStyleBackColor = true;
            this.btnALALLMixed.Click += new System.EventHandler(this.btnALALLMixed_Click);
            // 
            // btnSEasZ
            // 
            this.btnSEasZ.Location = new System.Drawing.Point(175, 86);
            this.btnSEasZ.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSEasZ.Name = "btnSEasZ";
            this.btnSEasZ.Size = new System.Drawing.Size(83, 45);
            this.btnSEasZ.TabIndex = 17;
            this.btnSEasZ.Text = "se as /z/";
            this.btnSEasZ.UseVisualStyleBackColor = true;
            this.btnSEasZ.Click += new System.EventHandler(this.btnSEasZ_Click);
            // 
            // btnQU
            // 
            this.btnQU.Location = new System.Drawing.Point(89, 86);
            this.btnQU.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnQU.Name = "btnQU";
            this.btnQU.Size = new System.Drawing.Size(83, 45);
            this.btnQU.TabIndex = 16;
            this.btnQU.Text = "qu";
            this.btnQU.UseVisualStyleBackColor = true;
            this.btnQU.Click += new System.EventHandler(this.btnQU_Click);
            // 
            // BlendsLetterBlendsPromptlabel
            // 
            this.BlendsLetterBlendsPromptlabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BlendsLetterBlendsPromptlabel.AutoSize = true;
            this.BlendsLetterBlendsPromptlabel.Location = new System.Drawing.Point(155, 43);
            this.BlendsLetterBlendsPromptlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BlendsLetterBlendsPromptlabel.Name = "BlendsLetterBlendsPromptlabel";
            this.BlendsLetterBlendsPromptlabel.Size = new System.Drawing.Size(213, 13);
            this.BlendsLetterBlendsPromptlabel.TabIndex = 15;
            this.BlendsLetterBlendsPromptlabel.Text = "Please select a category below to continue!";
            // 
            // BlendsLetterBlendslabel
            // 
            this.BlendsLetterBlendslabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BlendsLetterBlendslabel.AutoSize = true;
            this.BlendsLetterBlendslabel.Location = new System.Drawing.Point(206, 16);
            this.BlendsLetterBlendslabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BlendsLetterBlendslabel.Name = "BlendsLetterBlendslabel";
            this.BlendsLetterBlendslabel.Size = new System.Drawing.Size(107, 13);
            this.BlendsLetterBlendslabel.TabIndex = 14;
            this.BlendsLetterBlendslabel.Text = "Blends, Letter Blends";
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.Location = new System.Drawing.Point(218, 260);
            this.btnMainMenu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(83, 45);
            this.btnMainMenu.TabIndex = 28;
            this.btnMainMenu.Text = "Main Menu";
            this.btnMainMenu.UseVisualStyleBackColor = true;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            // 
            // BlendsLetterBlendsMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(519, 354);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.btnSchwaAAlaska);
            this.Controls.Add(this.btnQUASquash);
            this.Controls.Add(this.btnOY);
            this.Controls.Add(this.btnWAWater);
            this.Controls.Add(this.btnDGE);
            this.Controls.Add(this.btnAbleLatinSuffix);
            this.Controls.Add(this.btnOWPlow);
            this.Controls.Add(this.btnOUOut);
            this.Controls.Add(this.btnAll);
            this.Controls.Add(this.btnALALLMixed);
            this.Controls.Add(this.btnSEasZ);
            this.Controls.Add(this.btnQU);
            this.Controls.Add(this.BlendsLetterBlendsPromptlabel);
            this.Controls.Add(this.BlendsLetterBlendslabel);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "BlendsLetterBlendsMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "The Reading Tree";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSchwaAAlaska;
        private System.Windows.Forms.Button btnQUASquash;
        private System.Windows.Forms.Button btnOY;
        private System.Windows.Forms.Button btnWAWater;
        private System.Windows.Forms.Button btnDGE;
        private System.Windows.Forms.Button btnAbleLatinSuffix;
        private System.Windows.Forms.Button btnOWPlow;
        private System.Windows.Forms.Button btnOUOut;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.Button btnALALLMixed;
        private System.Windows.Forms.Button btnSEasZ;
        private System.Windows.Forms.Button btnQU;
        private System.Windows.Forms.Label BlendsLetterBlendsPromptlabel;
        private System.Windows.Forms.Label BlendsLetterBlendslabel;
        private System.Windows.Forms.Button btnMainMenu;
    }
}