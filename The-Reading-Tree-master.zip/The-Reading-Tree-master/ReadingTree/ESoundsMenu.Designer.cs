﻿namespace ReadingTree
{
    partial class ESoundsMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.btnEIlongELongA = new System.Windows.Forms.Button();
            this.btnEICeiling = new System.Windows.Forms.Button();
            this.btnEAEach = new System.Windows.Forms.Button();
            this.btnEABread = new System.Windows.Forms.Button();
            this.ASoundsPromptLabel = new System.Windows.Forms.Label();
            this.ESoundsLabel = new System.Windows.Forms.Label();
            this.btnEYValley = new System.Windows.Forms.Button();
            this.btnEE = new System.Windows.Forms.Button();
            this.btnEighNeighbor = new System.Windows.Forms.Button();
            this.btnEIReindeer = new System.Windows.Forms.Button();
            this.btnEAA = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.Location = new System.Drawing.Point(327, 423);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(125, 70);
            this.btnMainMenu.TabIndex = 30;
            this.btnMainMenu.Text = "Main Menu";
            this.btnMainMenu.UseVisualStyleBackColor = true;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            // 
            // btnEIlongELongA
            // 
            this.btnEIlongELongA.Location = new System.Drawing.Point(326, 224);
            this.btnEIlongELongA.Name = "btnEIlongELongA";
            this.btnEIlongELongA.Size = new System.Drawing.Size(125, 70);
            this.btnEIlongELongA.TabIndex = 29;
            this.btnEIlongELongA.Text = "ei long E and long A";
            this.btnEIlongELongA.UseVisualStyleBackColor = true;
            this.btnEIlongELongA.Click += new System.EventHandler(this.btnEIlongELongA_Click);
            // 
            // btnEICeiling
            // 
            this.btnEICeiling.Location = new System.Drawing.Point(197, 224);
            this.btnEICeiling.Name = "btnEICeiling";
            this.btnEICeiling.Size = new System.Drawing.Size(125, 70);
            this.btnEICeiling.TabIndex = 28;
            this.btnEICeiling.Text = "ei as /E/ (ceiling)";
            this.btnEICeiling.UseVisualStyleBackColor = true;
            this.btnEICeiling.Click += new System.EventHandler(this.btnEICeiling_Click);
            // 
            // btnEAEach
            // 
            this.btnEAEach.Location = new System.Drawing.Point(326, 148);
            this.btnEAEach.Name = "btnEAEach";
            this.btnEAEach.Size = new System.Drawing.Size(125, 70);
            this.btnEAEach.TabIndex = 27;
            this.btnEAEach.Text = "ea as /E/ (each)";
            this.btnEAEach.UseVisualStyleBackColor = true;
            this.btnEAEach.Click += new System.EventHandler(this.btnEAEach_Click);
            // 
            // btnEABread
            // 
            this.btnEABread.Location = new System.Drawing.Point(197, 148);
            this.btnEABread.Name = "btnEABread";
            this.btnEABread.Size = new System.Drawing.Size(125, 70);
            this.btnEABread.TabIndex = 26;
            this.btnEABread.Text = "ea as /e/ (bread)";
            this.btnEABread.UseVisualStyleBackColor = true;
            this.btnEABread.Click += new System.EventHandler(this.btnEABread_Click);
            // 
            // ASoundsPromptLabel
            // 
            this.ASoundsPromptLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ASoundsPromptLabel.AutoSize = true;
            this.ASoundsPromptLabel.Location = new System.Drawing.Point(233, 89);
            this.ASoundsPromptLabel.Name = "ASoundsPromptLabel";
            this.ASoundsPromptLabel.Size = new System.Drawing.Size(313, 20);
            this.ASoundsPromptLabel.TabIndex = 25;
            this.ASoundsPromptLabel.Text = "Please select a category below to continue!";
            // 
            // ESoundsLabel
            // 
            this.ESoundsLabel.AutoSize = true;
            this.ESoundsLabel.Location = new System.Drawing.Point(350, 42);
            this.ESoundsLabel.Name = "ESoundsLabel";
            this.ESoundsLabel.Size = new System.Drawing.Size(79, 20);
            this.ESoundsLabel.TabIndex = 24;
            this.ESoundsLabel.Text = "E Sounds";
            // 
            // btnEYValley
            // 
            this.btnEYValley.Location = new System.Drawing.Point(457, 224);
            this.btnEYValley.Name = "btnEYValley";
            this.btnEYValley.Size = new System.Drawing.Size(125, 70);
            this.btnEYValley.TabIndex = 32;
            this.btnEYValley.Text = "ey as /E/ (valley)";
            this.btnEYValley.UseVisualStyleBackColor = true;
            this.btnEYValley.Click += new System.EventHandler(this.btnEYValley_Click);
            // 
            // btnEE
            // 
            this.btnEE.Location = new System.Drawing.Point(457, 148);
            this.btnEE.Name = "btnEE";
            this.btnEE.Size = new System.Drawing.Size(125, 70);
            this.btnEE.TabIndex = 31;
            this.btnEE.Text = "EE";
            this.btnEE.UseVisualStyleBackColor = true;
            this.btnEE.Click += new System.EventHandler(this.btnEE_Click);
            // 
            // btnEighNeighbor
            // 
            this.btnEighNeighbor.Location = new System.Drawing.Point(457, 300);
            this.btnEighNeighbor.Name = "btnEighNeighbor";
            this.btnEighNeighbor.Size = new System.Drawing.Size(125, 70);
            this.btnEighNeighbor.TabIndex = 35;
            this.btnEighNeighbor.Text = "eigh as /A/ (neighbor)";
            this.btnEighNeighbor.UseVisualStyleBackColor = true;
            this.btnEighNeighbor.Click += new System.EventHandler(this.btnEighNeighbor_Click);
            // 
            // btnEIReindeer
            // 
            this.btnEIReindeer.Location = new System.Drawing.Point(326, 300);
            this.btnEIReindeer.Name = "btnEIReindeer";
            this.btnEIReindeer.Size = new System.Drawing.Size(125, 70);
            this.btnEIReindeer.TabIndex = 34;
            this.btnEIReindeer.Text = "ei as /A/ (reindeer)";
            this.btnEIReindeer.UseVisualStyleBackColor = true;
            this.btnEIReindeer.Click += new System.EventHandler(this.btnEIReindeer_Click);
            // 
            // btnEAA
            // 
            this.btnEAA.Location = new System.Drawing.Point(197, 300);
            this.btnEAA.Name = "btnEAA";
            this.btnEAA.Size = new System.Drawing.Size(125, 70);
            this.btnEAA.TabIndex = 33;
            this.btnEAA.Text = "ea as /A/";
            this.btnEAA.UseVisualStyleBackColor = true;
            this.btnEAA.Click += new System.EventHandler(this.btnEAA_Click);
            // 
            // ESoundsMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(778, 544);
            this.Controls.Add(this.btnEighNeighbor);
            this.Controls.Add(this.btnEIReindeer);
            this.Controls.Add(this.btnEAA);
            this.Controls.Add(this.btnEYValley);
            this.Controls.Add(this.btnEE);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.btnEIlongELongA);
            this.Controls.Add(this.btnEICeiling);
            this.Controls.Add(this.btnEAEach);
            this.Controls.Add(this.btnEABread);
            this.Controls.Add(this.ASoundsPromptLabel);
            this.Controls.Add(this.ESoundsLabel);
            this.Name = "ESoundsMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "The Reading Tree";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Button btnEIlongELongA;
        private System.Windows.Forms.Button btnEICeiling;
        private System.Windows.Forms.Button btnEAEach;
        private System.Windows.Forms.Button btnEABread;
        private System.Windows.Forms.Label ASoundsPromptLabel;
        private System.Windows.Forms.Label ESoundsLabel;
        private System.Windows.Forms.Button btnEYValley;
        private System.Windows.Forms.Button btnEE;
        private System.Windows.Forms.Button btnEighNeighbor;
        private System.Windows.Forms.Button btnEIReindeer;
        private System.Windows.Forms.Button btnEAA;
    }
}